__turbopack_load_page_chunks__("/_app", [
  "static/chunks/43c19863fe36e93b.js",
  "static/chunks/a9502a89c5467d8d.js",
  "static/chunks/0768df1ae6a31175.js",
  "static/chunks/a55e453750c2a7fa.css",
  "static/chunks/f114e33eea8ff240.css",
  "static/chunks/turbopack-d9a257a54cbf60a1.js"
])
