__turbopack_load_page_chunks__("/500", [
  "static/chunks/145eb876c506364c.js",
  "static/chunks/0778e064776a59a4.js",
  "static/chunks/0768df1ae6a31175.js",
  "static/chunks/bec589af7d03fb52.js",
  "static/chunks/ed98859daf75d16f.js",
  "static/chunks/b93312a88edc6c59.js",
  "static/chunks/526207a19b2d0169.js",
  "static/chunks/926fd7b58c973383.js",
  "static/chunks/turbopack-07ab30b2f0fb6b54.js"
])
