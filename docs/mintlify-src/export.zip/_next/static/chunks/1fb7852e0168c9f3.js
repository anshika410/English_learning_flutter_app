__turbopack_load_page_chunks__("/_app", [
  "static/chunks/b3e7f04921927c1a.js",
  "static/chunks/3ae3d620010ff219.js",
  "static/chunks/0768df1ae6a31175.js",
  "static/chunks/9e529d850a10a6d3.css",
  "static/chunks/f7ae8eaa4f895938.css",
  "static/chunks/turbopack-a8ef15f93c529d3c.js"
])
