__turbopack_load_page_chunks__("/404", [
  "static/chunks/d9cf38a896062f33.js",
  "static/chunks/0778e064776a59a4.js",
  "static/chunks/0768df1ae6a31175.js",
  "static/chunks/bec589af7d03fb52.js",
  "static/chunks/bc2286442ca2f631.js",
  "static/chunks/b93312a88edc6c59.js",
  "static/chunks/526207a19b2d0169.js",
  "static/chunks/68ec476dbc74d829.js",
  "static/chunks/turbopack-ec0a821140ff2ad6.js"
])
